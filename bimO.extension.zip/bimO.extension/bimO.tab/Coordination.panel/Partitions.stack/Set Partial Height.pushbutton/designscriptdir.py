import clr

clr.AddReference('ProtoGeometry')
from Autodesk.Revit.DB import *
import Autodesk.DesignScript.Geometry as DS
from Autodesk.DesignScript.Geometry import *

dir(DS)